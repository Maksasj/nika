# Antras uždavinys (JFlex scanner)

atliko Maksim Jaroslavcevas